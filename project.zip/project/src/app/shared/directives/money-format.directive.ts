import { Directive, ElementRef, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appMoneyFormat]'
})
export class MoneyFormatDirective {

  private regex: RegExp = new RegExp(/^\d{0,3}(,\d{3})*(\.\d{0,2})?$/);
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home'];

  constructor(private el: ElementRef, private control: NgControl) { }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }

    const current: string = this.control.control?.value || '';
    const next: string = current.concat(event.key);
    if (next && !String(next).match(this.regex)) {
      event.preventDefault();
    }
  }

  @HostListener('blur', ['$event'])
  onBlur(event: FocusEvent) {
    let value = this.control.control?.value;
    if (value) {
      value = this.formatCurrency(value);
      this.control.control?.setValue(value);
    }
  }

  private formatCurrency(value: string | number): string {
    if (typeof value === 'string') {
      value = parseFloat(value.replace(/,/g, ''));
    }
    return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
}
