import {AbstractControl, FormGroup, ValidatorFn} from "@angular/forms";

export class RegexValidators {
    static patternValidator(regex: RegExp, condition:string, error: {[key: string]: boolean}): ValidatorFn {
        return (control: AbstractControl): { [key: string]: boolean } | null => {
            if(!control.value) {
                return null;
            }
            const valid = regex.test(control.value);
            const condition = FormGroup.get()
            return valid ? null : error;
        }
    }
}