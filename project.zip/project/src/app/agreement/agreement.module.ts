import { CurrencyPipe } from '@angular/common';

export class AgreementModule { 
  id?: number;
  subject?: string;
  quantity?: number;
  money?: CurrencyPipe;
  agreementNum?: string;
  agreementDate?: Date;
  agreementExp?: Date;
  deliveryDate?: Date;
  deliveringOrg?: number;
  isSecret?: boolean;
  licenseExp?: Date;
  letterNum?: string;
  letterInit?: string;
  financeCode?: string;
 }
