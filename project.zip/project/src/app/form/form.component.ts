import { Component } from '@angular/core';
import { HeaderComponent } from "../header/header.component";
import { Form, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegexValidators } from '../shared/validators/regex-validators';

@Component({
    selector: 'app-form',
    standalone: true,
    templateUrl: './form.component.html',
    styleUrl: './form.component.css',
    imports: [HeaderComponent]
})
export class FormComponent {
    agreementForm?: FormGroup;

    constructor(private fb: FormBuilder) {}

    ngOnInit(): void {
        this.agreementForm = this.fb.group({
            subject: ["", Validators.required],
            quantity?: [""],
            money?: ["", Validators.required],
            agreementNum?: ['', [Validators.required, RegexValidators.patternValidator(/^\w{2}[/]\w{3}$/, { invalidPattern: true })]],
            agreementDate?: 
            agreementExp?: 
            deliveryDate?: 
            deliveringOrg?: 
            isSecret?:
            licenseExp?: 
            letterNum?: 
            letterInit?:
            financeCode?: 
        })
    }
}
